# firstpackage
This library was created as an exercise in publishing Python packages to GitHub

## Building this package locally
`python setup.py sdist`

## Installing this package from GitHub
`pip install git+https://github.com/RobynLeighSmith2/firstpackage.git`

## Updating this package from GitHub
`pip install --upgrade git+https://github.com/RobynLeighSmith2/firstpackage.git`
